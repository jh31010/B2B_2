from setuptools import setup, find_packages

setup(
    name="my_project",
    version="1.0.0",
    author="Your Name",
    description="A sample Python project",
    packages=find_packages(),
    install_requires=[
        "numpy",
        "requests"
    ],
    entry_points={
        "console_scripts": [
            "my_project=my_project.main:main_function"
        ]
    }
)